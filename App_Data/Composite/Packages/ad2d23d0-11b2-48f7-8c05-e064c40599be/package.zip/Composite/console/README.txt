Required for development:

1) Check version of node.js - should be >4.* (cmd -> node -v => https://nodejs.org/en/)
2) Check that Visual Studio uses correct node executable (https://ryanhayes.net/synchronize-node-js-install-version-with-visual-studio-2015/)

To run scripts in Visual Studio (not required if these are run only in command line/PowerShell):

1) Install npm Task runner: https://marketplace.visualstudio.com/items?itemName=MadsKristensen.NPMTaskRunner
2) Locate npm scripts in Task Runner Explorer, in Website project
