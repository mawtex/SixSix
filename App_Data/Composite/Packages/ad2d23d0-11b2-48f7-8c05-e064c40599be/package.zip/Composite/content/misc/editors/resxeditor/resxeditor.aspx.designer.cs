﻿public partial class ResxEditor
{
    protected global::Composite.Core.WebClient.UiControlLib.Feedback ctlFeedback;

    protected global::System.Web.UI.WebControls.Repeater DataRepeater;
}