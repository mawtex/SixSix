Packaged with https://highlightjs.org/download/ with the following language options selected:

HTML/XML,HTTP,CSS,LESS,JavaScript,JSON,TypeScript,C#,Markdown